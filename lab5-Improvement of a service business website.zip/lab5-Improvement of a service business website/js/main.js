function myFunction() {
    document.getElementById("myAlert").style.visibility = "visible";
}